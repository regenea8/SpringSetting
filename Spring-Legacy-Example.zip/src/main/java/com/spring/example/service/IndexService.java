package com.spring.example.service;

import java.util.List;

public interface IndexService {
	
	public List testList() throws Exception;
}
