package com.spring.example;

public class TestMain {

	public static void main(String[] args) {
		System.out.println("test");
	}

}
