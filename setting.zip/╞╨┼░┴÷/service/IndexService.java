package com.regenea8.setting.service;

import java.util.List;

public interface IndexService {
	
	public List testList() throws Exception;
}
