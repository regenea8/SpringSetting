package com.regenea8.setting.dao;

import java.util.List;
import java.util.Map;

public interface IndexDAO {
	public List testList() throws Exception;
}
